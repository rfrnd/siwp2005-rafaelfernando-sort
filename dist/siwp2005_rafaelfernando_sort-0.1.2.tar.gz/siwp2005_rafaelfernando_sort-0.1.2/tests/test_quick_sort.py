from src.sort.quick_sort import quick_sort

arr = [45, 23, 78, 12, 56, 89, 31]
sorted_arr = quick_sort(arr)
print("Sorted array is:", sorted_arr)