import setuptools

setuptools.setup()
